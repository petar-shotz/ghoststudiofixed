import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Ghost Studio — Big ideas. Boo-tiful websites.",
    template: "%s | Ghost Studio",
  },
  description:
    "Custom website design studio with 5-step project planner, secure admin lead management, and reliable email notifications for ghoststudio.mk",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
  openGraph: {
    title: "Ghost Studio — Big ideas. Boo-tiful websites.",
    description: "Custom website design studio with 5-step project planner and reliable client brief workflows.",
    url: "https://ghoststudio.mk",
    siteName: "Ghost Studio",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ghost Studio — Big ideas. Boo-tiful websites.",
    description: "Custom website design studio with 5-step project planner.",
  },
};

export const viewport: Viewport = {
  themeColor: "#effa82",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <a className="skip-link" href="#main-content">
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
